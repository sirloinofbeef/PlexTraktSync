#!/usr/bin/env python3

from plex_trakt_sync.clear_trakt_collections import clear_trakt_collections

if __name__ == "__main__":
    clear_trakt_collections()
