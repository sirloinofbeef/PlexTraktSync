#!/usr/bin/env python3

from plex_trakt_sync.get_env_data import get_env_data

if __name__ == "__main__":
    get_env_data()
