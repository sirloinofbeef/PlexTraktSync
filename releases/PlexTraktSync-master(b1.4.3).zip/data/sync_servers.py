from shutil import copyfile
import datetime
from urllib.request import urlopen
import urllib

# ------------- START VERSION CHECK ------------------------
data = urlopen("https://raw.githubusercontent.com/sirloinofbeef/PlexTraktSync/master/data/plex_trakt_sync/version.txt")
vlatest = data.readline().decode('utf8').rstrip()

with open('plex_trakt_sync/version.txt') as f: vinstalled = f.readline()

if 'b' in vinstalled:
   print("You are using a beta: v" + vinstalled)
elif vlatest == vinstalled:
    print("You are using the latest version: v" + vinstalled)
else:
    print("An update is available!\nInstalled: v" + vinstalled + "\nNew:       v" + vlatest + "\n\nPlease update from https://github.com/sirloinofbeef/PlexTraktSync/wiki\n")
# ------------- END VERSION CHECK ------------------------


# ----- Start If lone config exists then backup as hawke config ----------------------

def BackupHawkeConfig():
   try:
       with open('configs/.env - hawke') as f:
          print ("Hawke.one config found")
   except IOError:
      print ("No Hawke.one config found. Running setup...")
      try:
          with open('.env') as f:
             copyfile('.env', 'configs/.env - hawke')
             print("Creating Hawke.one config... Done!")
             copyfile('.pytrakt.json', 'configs/.pytrakt.json - hawke')
      except IOError:
        print("-----------------------------------------------------------------------------------")
        print(" Hawke.one - Trakt Sync - setup")
        print("-----------------------------------------------------------------------------------")
        import main

# ----- End If lone config exists then backup as hawke config ---------------------

BackupHawkeConfig()

try:
    with open('configs/.env - hawke') as f:
        today = datetime.datetime.now()
        print("-----------------------------------------------------------------------------------")
        print(" Hawke.one - Trakt Sync started on " + str(today.strftime("%B %d %Y at %H:%M:%S")))
        print("-----------------------------------------------------------------------------------")
        print("Connecting to Hawke.one server...")
        copyfile('configs/.env - hawke', '.env')
        copyfile('configs/.pytrakt.json - hawke', '.pytrakt.json')
        exec(open("main.py").read())
except IOError:
    print("\n")

try:
    with open('configs/.env - 2') as f:
        today = datetime.datetime.now()
        print("-----------------------------------------------------------------------------------")
        print(" Plex Server 2 - Trakt Sync started on " + str(today.strftime("%B %d %Y at %H:%M:%S")))
        print("-----------------------------------------------------------------------------------")
        print("Connecting to Plex server 2...")
        copyfile('configs/.env - 2', '.env')
        copyfile('configs/.pytrakt.json - 2', '.pytrakt.json')
        exec(open("main.py").read())
except IOError:
    print("\n")

try:
    with open('configs/.env - 3') as f:
        today = datetime.datetime.now()
        print("-----------------------------------------------------------------------------------")
        print(" Plex Server 3 - Trakt Sync started on " + str(today.strftime("%B %d %Y at %H:%M:%S")))
        print("-----------------------------------------------------------------------------------")
        print("Connecting to Plex server 3...")
        copyfile('configs/.env - 3', '.env')
        copyfile('configs/.pytrakt.json - 3', '.pytrakt.json')
        exec(open("main.py").read())
except IOError:
    print("\n")

try:
    with open('configs/.env - 4') as f:
        today = datetime.datetime.now()
        print("-----------------------------------------------------------------------------------")
        print(" Plex Server 4 - Trakt Sync started on " + str(today.strftime("%B %d %Y at %H:%M:%S")))
        print("-----------------------------------------------------------------------------------")
        print("Connecting to Plex server 4...")
        copyfile('configs/.env - 4', '.env')
        copyfile('configs/.pytrakt.json - 4', '.pytrakt.json')
        exec(open("main.py").read())
except IOError:
    print("\n")

try:
    with open('configs/.env - 5') as f:
        today = datetime.datetime.now()
        print("-----------------------------------------------------------------------------------")
        print(" Plex Server 5 - Trakt Sync started on " + str(today.strftime("%B %d %Y at %H:%M:%S")))
        print("-----------------------------------------------------------------------------------")
        print("Connecting to Plex server 4...")
        copyfile('configs/.env - 5', '.env')
        copyfile('configs/.pytrakt.json - 5', '.pytrakt.json')
        exec(open("main.py").read())
except IOError:
    print("\n")