from shutil import copyfile
import datetime
from urllib.request import urlopen
import urllib
import os
import shutil

# ------------- START VERSION CHECK ------------------------
data = urlopen("https://raw.githubusercontent.com/sirloinofbeef/PlexTraktSync/master/data/plex_trakt_sync/version.txt")
vlatest = data.readline().decode('utf8').rstrip()

with open('plex_trakt_sync/version.txt') as f: vinstalled = f.readline()

if vlatest == vinstalled:
    print("You are using the latest version: v" + vinstalled)
else:
    print("An update is available!\nInstalled: v" + vinstalled + "\nNew:       v" + vlatest + "\n\nPlease update from https://github.com/sirloinofbeef/PlexTraktSync/wiki")
# ------------- END VERSION CHECK ------------------------


print("-----------------------------------------------------------------------------------")
print("Hawke.one - Trakt Sync - Add server")
print("-----------------------------------------------------------------------------------")

print ("What would you like to do?")
print (" 1: Remove existing server configs and start from scratch.")
print (" 2: Add a new server alongside your existing configs.")
print (" 3. Cancel")
ConfigChoice = input('\n Please enter your choice (1-3): ')

if ConfigChoice == "1":
   if os.path.exists(".env"):
      os.remove(".env")
   if os.path.exists(".pytrakt.json"):
      os.remove(".pytrakt.json")
   shutil.rmtree('configs')
   os.mkdir('configs')
   print ("\nRemoving existing server configs... Done!")
   print ("Resetting...\n")
   import main

elif ConfigChoice == "2":
   if os.path.exists(".env"):
      os.remove(".env")
   if os.path.exists(".pytrakt.json"):
      os.remove(".pytrakt.json")
   print ("\nCommencing new server config. \nPlease let the initial sync complete in order to succesfully add the server.\n")   
   import main
   print ("Backing up new server config...")
   if os.path.exists("configs/.env - 1"):
         if os.path.exists("configs/.env - 2"):
            if os.path.exists("configs/.env - 3"):
                if os.path.exists("configs/.env - 4"):
                   print("Whilst this one time sync has been completed, you are already syncing your maximum 5 servers, and this configuration will not be saved.")
                else:
                   copyfile('.env', 'configs/.env - 4')
                   copyfile('.pytrakt.json', 'configs/.pytrakt.json - 4')
                   print("Server config saved as server 4")
            else:
              copyfile('.env', 'configs/.env - 3')
              copyfile('.pytrakt.json', 'configs/.pytrakt.json - 3')
              print("Server config saved as server 3")
         else:
           copyfile('.env', 'configs/.env - 2')
           copyfile('.pytrakt.json', 'configs/.pytrakt.json - 2')
           print("Server config saved as server 2")
   else:
        copyfile('.env', 'configs/.env - 1')
        copyfile('.pytrakt.json', 'configs/.pytrakt.json - 1')
        print("Server config saved as server 1")
else:
    exit()